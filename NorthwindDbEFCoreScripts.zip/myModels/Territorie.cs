﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyEFCORENorthwindDB.myModels
{
    internal class Territorie
    {
        public int TerritorieID { get; set; }   

        public string TerritorieDescription { get; set; }   

        public Region region { get; set; }  

        public ICollection<Employee> Employees { get; set; }

    }
}
