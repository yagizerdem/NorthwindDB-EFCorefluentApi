﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyEFCORENorthwindDB.myModels
{
    internal class EmployeeTerritories
    {
        public int EmployeeID { get; set; } 

        public int TerritoryID { get; set; }    
    }
}
