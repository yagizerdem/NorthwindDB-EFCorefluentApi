﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyEFCORENorthwindDB.myModels
{
    internal class Categorie
    {
        public int CategorieID { get; set; } 

        public string CategoryName { get; set; }    

        public string? Description { get; set; } 

        public byte[]? Picture { get; set; }


        public ICollection<Product> Products { get; set; }
         
    }
}
