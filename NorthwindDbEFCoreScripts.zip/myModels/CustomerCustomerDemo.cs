﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyEFCORENorthwindDB.myModels
{
    internal class CustomerCustomerDemo
    {
        public int CustomerId { get; set; } 

        public int CustomerTypeId { get; set; } 
    }
}
