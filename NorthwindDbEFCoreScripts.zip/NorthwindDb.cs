﻿using Microsoft.EntityFrameworkCore;
using MyEFCORENorthwindDB.myModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace MyEFCORENorthwindDB
{
    internal class NorthwindDb:DbContext
    {

        public DbSet<Categorie> Categories { get; set;}

        public DbSet<Customer> Customers { get; set;}   

        public DbSet<CustomerCustomerDemo> CustomersDemo { get; set;}   

        public DbSet<CustomerDemographics> CustomersDemographics { get; set;}

        public DbSet<Employee> Employees { get; set; }

        public DbSet<EmployeeTerritories> EmployeeTerritories { get; set; }

        public DbSet<Order> Orders { get;set;}

        public DbSet<Product> Products { get; set;}

        public DbSet<Region> Regions { get; set;}

        public DbSet<Shipper> Shipper { get; set;}    

        public DbSet<Supplier> Suppliers { get; set;}

        public DbSet<Territorie> Territories { get; set;}



        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {

            optionsBuilder.UseSqlServer("Server=.;Database=MyNortwind;Trusted_Connection=True;TrustServerCertificate=True;");

            base.OnConfiguring(optionsBuilder);
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

            modelBuilder.Entity<Categorie>(t =>
            {
                t.Property(t=>t.CategoryName).HasColumnType("nvarchar(15)");
                t.Property(t => t.Description).HasColumnType("nvarchar(15)");
                t.Property(t => t.Picture).HasColumnType("image");
            });

            modelBuilder.Entity<CustomerCustomerDemo>(t =>
            {
                t.Property(t => t.CustomerId).HasColumnType("nchar(5)");
                t.Property(t => t.CustomerTypeId).HasColumnType("nchar(5)");
    
            });

            modelBuilder.Entity<Territorie>(t =>
            {
                t.HasMany(c=>c.Employees).WithMany(x=>x.Territories).UsingEntity<EmployeeTerritories>(y=>y.HasOne<Employee>().WithMany().HasForeignKey(u=>u.EmployeeID),o=>o.HasOne<Territorie>().WithMany().HasForeignKey(v=>v.TerritoryID));
                t.Property(t => t.TerritorieDescription).HasColumnType("nchar(50)");
            
            });


            modelBuilder.Entity<Order>(t =>
            {
                t.HasMany(c => c.Products).WithMany(x => x.Orders).UsingEntity<OrderDetails>(y => y.HasOne<Product>().WithMany().HasForeignKey(u => u.ProductID), o => o.HasOne<Order>().WithMany().HasForeignKey(v=>v.OrderID));

                t.Property(t => t.CustomerId).HasColumnType("nchar(5)");
                t.Property(t => t.OrderDate).HasColumnType("datetime");
                t.Property(t => t.RequiredDate).HasColumnType("datetime");
                t.Property(t => t.ShippedDate).HasColumnType("datetime");
                t.Property(t => t.ShipVia).HasColumnType("money");
                t.Property(t => t.Freight).HasColumnType("datetime");
                t.Property(t => t.ShipName).HasColumnType("nvarchar(40)");
                t.Property(t => t.ShipAddress).HasColumnType("nvarchar(60)");
                t.Property(t => t.ShipCity).HasColumnType("nvarchar(15)");
                t.Property(t => t.ShipRegion).HasColumnType("nvarchar(15)");
                t.Property(t => t.ShipPostalCode).HasColumnType("nvarchar(10)");
                t.Property(t => t.ShipCountry).HasColumnType("nvarchar(15)");
                t.Property(t => t.ShipCountry).HasColumnType("nvarchar(15)");
            });

            modelBuilder.Entity<Customer>(t =>
            {
                t.HasMany(c => c.CustomerDemographics).WithMany(x => x.Customers).UsingEntity<CustomerCustomerDemo>(y => y.HasOne<CustomerDemographics>().WithMany().HasForeignKey(u => u.CustomerTypeId), o => o.HasOne<Customer>().WithMany().HasForeignKey(v => v.CustomerId));
                t.Property(t=>t.CompanyName).HasColumnType("nvarchar(40)");
                t.Property(t => t.ContactName).HasColumnType("nvarchar(30)");
                t.Property(t => t.ContactTile).HasColumnType("nvarchar(30)");
                t.Property(t => t.Address).HasColumnType("nvarchar(60)");
                t.Property(t => t.City).HasColumnType("nvarchar(15)");
                t.Property(t => t.Region).HasColumnType("nvarchar(15)");
                t.Property(t => t.PostalCode).HasColumnType("nvarchar(10)");
                t.Property(t => t.Country).HasColumnType("nvarchar(15)");
                t.Property(t => t.Phone).HasColumnType("nvarchar(24)");
                t.Property(t => t.Fax).HasColumnType("nvarchar(24)");
            });


            modelBuilder.Entity<CustomerDemographics>(t =>
            {
                t.HasKey(t => t.CustomerTypeID);
                t.Property(t => t.CustomerTypeID).HasColumnType("nchar(10)");
                t.Property(t => t.CustomerDesc).HasColumnType("ntext").IsRequired(false);
            });


            modelBuilder.Entity<Shipper>(t =>
            {
                t.HasMany(x => x.Orders).WithOne(t=>t.Shipper).HasForeignKey(t=>t.ShipVia);
                t.Property(t => t.CompanyName).HasColumnType("ncahr(40)");
                t.Property(t => t.Phone).HasColumnType("nvarchar(24)");
            });


            modelBuilder.Entity<Employee>().HasMany(t => t.subemployees).WithOne(t => t.employee).HasForeignKey(t => t.ReportsTo).IsRequired(false);

            modelBuilder.Entity<Employee>(t =>
            {
                t.Property(t=>t.LastName).HasColumnType("nvarchar(20)");
                t.Property(t => t.FirstName).HasColumnType("nvarchar(10)");
                t.Property(t => t.Title).HasColumnType("nvarchar(30)");
                t.Property(t => t.TitleOfCourtesy).HasColumnType("nvarchar(25)");
                t.Property(t => t.BirthDate).HasColumnType("datetime");
                t.Property(t => t.HireDate).HasColumnType("datetime");
                t.Property(t => t.Address).HasColumnType("nvarchar(15)");
                t.Property(t => t.City).HasColumnType("nvarchar(15)");
                t.Property(t => t.Region).HasColumnType("nvarchar(15)");
                t.Property(t => t.PostalCode).HasColumnType("nvarchar(10)");
                t.Property(t => t.Country).HasColumnType("nvarchar(15)");
                t.Property(t => t.HomePhone).HasColumnType("nvarchar(24)");
                t.Property(t => t.Extension).HasColumnType("nvarchar(4)");
                t.Property(t => t.Photo).HasColumnType("image");
                t.Property(t => t.Notes).HasColumnType("ntext");
                t.Property(t => t.ReportsTo).HasColumnType("int");
                t.Property(t => t.PhotoPath).HasColumnType("nvarchar(255)");
            });


            modelBuilder.Entity<EmployeeTerritories>(t =>
            {
                t.Property(t => t.EmployeeID).HasColumnType("int");
                t.Property(t => t.TerritoryID).HasColumnType("narchar(20)");
            });

            modelBuilder.Entity<OrderDetails>(t =>
            {
                t.Property(t => t.UnitPrice).HasColumnType("money");
                t.Property(t => t.Quantity).HasColumnType("smallint");
                t.Property(t => t.Discount).HasColumnType("real");
            });


            modelBuilder.Entity<Product>(t =>
            {
                t.Property(t => t.ProductName).HasColumnType("nvarchar(40)");
                t.Property(t => t.QuantityPerUnit).HasColumnType("nvarchar(20)");
                t.Property(t => t.QuantityPerUnit).HasColumnType("nvarchar(20)");
                t.Property(t => t.UnitPrice).HasColumnType("money");
                t.Property(t => t.UnitsInStock).HasColumnType("smallint");
                t.Property(t => t.UnitsOnOrder).HasColumnType("smallint");
                t.Property(t => t.RecrdLevel).HasColumnType("smallint");
                t.Property(t => t.Discountinued).HasColumnType("bit");
            });

            modelBuilder.Entity<Region>(t =>
            {
                t.Property(t => t.RegionDescription).HasColumnType("ncahr(50)");
            });

            modelBuilder.Entity<Supplier>(t =>
            {
                t.Property(t => t.CompanyName).HasColumnType("nvarchar(40)");
                t.Property(t => t.ContactName).HasColumnType("nvarchar(30)");
                t.Property(t => t.ContactTitle).HasColumnType("nvarchar(30)");
                t.Property(t => t.Address).HasColumnType("nvarchar(60)");
                t.Property(t => t.City).HasColumnType("nvarchar(15)");
                t.Property(t => t.Region).HasColumnType("nvarchar(15)");
                t.Property(t => t.PostalCode).HasColumnType("nvarchar(10)");
                t.Property(t => t.Country).HasColumnType("nvarchar(15)");
                t.Property(t => t.Phone).HasColumnType("nvarchar(24)");
                t.Property(t => t.Fax).HasColumnType("nvarchar(24)");
                t.Property(t => t.HomePage).HasColumnType("ntext");
            });

           

            base.OnModelCreating(modelBuilder);
            
        }


    }
}
